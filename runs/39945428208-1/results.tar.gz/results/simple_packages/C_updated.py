# Executable suite. Case fixtures and policy are shared.

def test_C001_0():
    assert verify_case('C001')

def test_C002_0():
    assert verify_case('C002')

def test_C004_0():
    assert verify_case('C004')

def test_C034_0():
    assert verify_case('C034')

def test_C044_0():
    assert verify_case('C044')

def test_C100_0():
    assert verify_case('C100')
