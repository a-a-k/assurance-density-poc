# Executable suite. Case fixtures and policy are shared.

def test_C100_0():
    assert assert_case('C100')

def test_C102_0():
    assert assert_case('C102')

def test_C104_0():
    assert assert_case('C104')

def test_C106_0():
    assert assert_case('C106')

def test_C108_0():
    assert assert_case('C108')
