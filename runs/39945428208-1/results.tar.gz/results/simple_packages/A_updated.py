# Executable suite. Case fixtures and policy are shared.
CASE_IDS = ('C001', 'C002', 'C004', 'C034', 'C044')

def test_cases_0():
    verdicts = [verify_case(case_id) for case_id in CASE_IDS]
    assert all(verdicts)
